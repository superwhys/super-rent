# Super Rent API接口文档

pip3 install -r requirements.txt

运行方式：python3 run.py

接口文档地址： /docs